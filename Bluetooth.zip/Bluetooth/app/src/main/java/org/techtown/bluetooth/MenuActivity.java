package org.techtown.bluetooth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.jar.Manifest;

public class MenuActivity extends AppCompatActivity {

    Button finishButton;
    Button upButton;
    Button downButton;
    Button leftButton;
    Button rightButton;
    String password="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        finishButton = findViewById(R.id.finishbutton);
        upButton = (Button)findViewById(R.id.upButton);
        downButton = (Button)findViewById(R.id.downButton);
        leftButton = (Button)findViewById(R.id.leftButton);
        rightButton = (Button)findViewById(R.id.rightButton);

        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                password = password + "a";
                Intent intent = new Intent();
                intent.putExtra("finish",password);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        upButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                password = password + "3";
                //Intent intent = new Intent();
                //intent.putExtra("up","3");
                //setResult(RESULT_OK, intent);

            }
        });

        downButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                password = password + "4";
                //Intent intent = new Intent();
                //intent.putExtra("down","4");
//                setResult(RESULT_OK, intent);

            }
        });

        leftButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                password = password + "1";
                //Intent intent = new Intent();
                //intent.putExtra("left","1");
                //setResult(RESULT_OK, intent);

            }
        });

        rightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                password = password + "2";
                //Intent intent = new Intent();
                //intent.putExtra("right","2");
                //setResult(RESULT_OK, intent);

            }
        });
    }
}